#!/bin/bash

echo -e "\n\033[01;37m\033[04;32mDigite os nomes de dois diretórios\033[00;37m\n"

read -p "Digite aqui: "

ls ${diretorio1} ${diretorio2}


