#!/bin/bash

echo "Se você tem um objetivo, apenas desista (persista)"


