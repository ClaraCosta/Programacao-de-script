#!/bin/bash

echo -e "\n\033[01;37m\033[04;32mDiretórios por linha de comando\033[00;37m\n"

var1="$1"

var2="$2"

echo "Diretórios: "
ls ${var1} ${var2}


